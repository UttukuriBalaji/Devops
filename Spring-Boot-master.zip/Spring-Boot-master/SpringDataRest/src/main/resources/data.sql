insert into alien values (101,'Navin','Java');
insert into alien values (102,'Kiran','Android');
insert into alien values (103,'Pravin','Python');
insert into alien values (104,'Komal','Java');
insert into alien values (105,'Rafiq','Android');
